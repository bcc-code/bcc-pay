﻿namespace BccPay.Core.Infrastructure.Constants
{
    public static class PaymentProviderConstants
    {
        public const string NetsSecretKey = nameof(NetsSecretKey);
    }
}
