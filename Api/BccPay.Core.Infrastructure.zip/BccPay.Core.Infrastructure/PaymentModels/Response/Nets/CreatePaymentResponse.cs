﻿namespace BccPay.Core.Infrastructure.PaymentModels.Response.Nets
{
    public class CreatePaymentResponse
    {
        public string PaymentId { get; set; }
    }
}
