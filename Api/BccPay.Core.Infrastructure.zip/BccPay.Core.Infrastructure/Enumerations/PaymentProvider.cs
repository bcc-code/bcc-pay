﻿namespace BccPay.Core.Infrastructure.Enumerations
{
    public enum PaymentProvider
    {
        CreditCard = 0,
        Nets = 1,
        Vipps = 2
    }
}
